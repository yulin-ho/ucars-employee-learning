---
name: ucars-employee-avatar
description: Generate consistent UCARS employee avatar images from a real employee photo and a style reference. Use when the user asks to create, regenerate, or batch-produce UCARS staff avatars.
---

# UCARS 员工头像

把员工真人照片转换为统一的简化 3D Memoji 头像，并保留本人辨识度。

## 默认参考图

- 核心风格锚点：[assets/ucars-avatar-style-reference.png](assets/ucars-avatar-style-reference.png)。该图决定头像系统的基础画风、白底、黑色 UCARS T 恤、挂绳和黄色工牌。
- 多样性案例： [assets/style-case-vest-01.png](assets/style-case-vest-01.png)、[assets/style-case-vest-02.png](assets/style-case-vest-02.png)、[assets/style-case-vest-03.jpg](assets/style-case-vest-03.jpg)。这些案例用于参考同一头像系统里不同脸型、发型块面及工作服细节的表现范围，不作为身份来源。
- 默认生成时使用核心风格锚点及 1–2 张多样性案例作为风格参考，员工真人照作为身份参考并放在最后。明确标注哪些图只决定风格，哪张图决定人物身份。不要把多个模板人物的面容平均或迁移给员工。
- 用户本轮提供了风格模板时，优先使用用户指定的模板；除非用户另有说明，参考顺序固定为：图 1 风格模板，图 2 员工真人照。
- 用户明确指定无工牌、有工牌或其他服装细节时，以本轮指示覆盖默认模板。
- 案例盘点和完整可复制提示词见 [references/prompt-template.md](references/prompt-template.md)。

## 生成流程

1. 确认哪几张是员工本人照片、哪几张是风格参考。多张员工照片按人分别生成，不把多个人合成一张图。
2. 使用 `image_gen__imagegen`。默认将核心风格锚点和 1–2 张案例图放在员工照片之前，员工照片最后；在提示词中逐一说明前面的图片只控制风格，最后一张只控制身份。用户本轮给出新的模板时，按用户指定的图序执行。
3. 采用统一简化 3D Memoji 视觉：圆润、低细节、平滑轻微塑料质感、柔和均匀光照、纯白底、正面居中、自然成人比例、头肩及上胸构图。严格保留员工本人脸型、五官比例、肤色、年龄感和发型；不美化、不瘦脸、不年轻化、不重设计发型。
4. 默认服装参考核心锚点：黑色圆领短袖 UCARS T 恤、穿着者左胸小尺寸黄色 UCARS Logo，以及黑色挂绳与黄色矩形工牌。多样性案例只提供统一画风下的变化范围，不能擅自把马甲、夹克等细节加到所有员工身上。用户明确选择某案例的服装或要求无工牌时再相应调整；工牌不生成姓名或小字。
5. 保持表情自然中性、闭嘴、不露齿；不夸张大眼、不幼童化。不得加入模板外的配饰、手势、道具、背景元素、额外文字或水印。
6. 每张照片单独生成一张成品。结果存放在图像生成工具返回的位置；除非用户明确要求，不覆盖或改动原始照片，也不自动复制到其他文件夹。
7. 回复时给出生成结果和可打开的文件路径，并简短提示核对本人辨识度、Logo/工牌文字。图中文字可能失真，不要承诺品牌文字百分百准确。

## 隐私与服务边界

员工肖像提交给图像生成服务前，确认用户已授权把当前指定照片用于 Codex 图像生成。用户明确要求“用这张照片生成头像”且当前执行使用的是 Codex 图像生成时可继续；若用户只要求整理提示词或讨论方案，不要上传照片。此 Skill 使用 Codex 图像生成，不代表飞书一键出图已接通。
