# UCARS Avatar Prompt and Case Notes

## Copy-ready prompt

使用两张参考图生成一张 UCARS 员工统一头像。

**参考图优先级：**前面的参考图均为 UCARS 员工头像风格案例，只决定统一画风、构图、人物比例、五官简化程度和材质；最后一张图是员工真人照片，只用于识别并还原该员工身份。风格案例优先级决定视觉系统，但不能让模板人物的身份、脸型、面容或发型迁移到员工身上。多张案例用于展示风格变化范围，不要把不同模板人物的面貌平均融合。

保留图 2 员工的真实脸型与脸宽、额头比例、眉形、眼型与眼距、鼻型和宽度、嘴型、下颌、耳朵、肤色、发型轮廓和成年年龄感。目标是本人可辨认，但不美化、不瘦脸、不尖下巴、不改变五官比例、不年轻化、不重新设计发型。头发严格按真人照的长短、刘海、分缝、发际线、两侧长度、顶部高度和轮廓，用少量整齐块面表现，不画真实发丝。

采用简化 3D Memoji / 系统 Emoji 品牌员工头像风格：圆润、简洁、低细节、几何化、平滑、轻微塑料质感；专业、干净、统一，明显非写实。自然大小的眼睛、简洁稍粗的块面眉毛、圆润简化的鼻子、小而自然闭合的嘴。表情中性、平静、友好但克制，不露齿、不明显微笑，不幼童化，不做夸张大眼。皮肤干净均匀，无毛孔、唇纹、细小皱纹或真实皮肤纹理。柔和均匀光线，不使用摄影棚人像效果、电影光影或景深。

穿纯黑色基础款圆领短袖 UCARS T 恤，穿着者左胸放置小尺寸黄色 UCARS Logo。默认按核心风格模板添加黑色挂绳及黄色矩形工牌；挂绳和工牌的大小、位置、质感参考核心风格模板，工牌正面使用简洁黑色 UCARS 笑脸/U 形标志，不添加姓名或小字。多样性案例不代表默认添加马甲、夹克等其他服装；只有用户明确选择相应案例服装时才采用。若本次明确要求无工牌，则不添加挂绳和工牌。不得添加其他服饰、配饰、首饰、帽子、耳机或手表；若员工真人照中有长期佩戴且清楚可见的眼镜，则保留眼镜。

人物正面朝向镜头，视线直视前方，身体正面，肩膀自然，不歪头、不侧身、不做手势。居中、基本对称，展示头部、肩膀和上胸部；头部大小、肩膀高度、胸部裁切范围与图 1 一致，头顶留适量白边。纯白背景，无渐变、环境、门店、装饰图形或背景阴影。只出现一人，不加额外文字、水印或道具。最终头像必须像图 1 所属的同一套 UCARS 头像系统，只改变员工本人的身份特征。

## Negative prompt

photorealistic portrait, realistic skin texture, pores, lip lines, wrinkles, realistic hair strands, Pixar style, Disney style, anime, idol style, game character, oversized eyes, baby face, V-shaped face, sharp chin, slim face, beauty filter, younger appearance, exaggerated smile, teeth, hairstyle redesign, side part if absent from source, fluffy realistic hair, cinematic lighting, studio photography, depth of field, dramatic shadows, extra accessories, hand gestures, props, complex background, extra text, watermark, extra person.

## 案例结论

- 指定员工头像目录中有 13 张单独图片、一个头像 ZIP 和员工表；ZIP 内含 15 张已生成头像案例。原图与生成图应按各自文件名/文件夹区分，处理前先确认参考图角色。
- 案例整体采用正面、方形、白底、简化 3D Emoji/Memoji 人物头像，常见黑色 UCARS 上衣。
- 案例间脸型、发型造型和服装细节存在变化：有的穿马甲或夹克，有的只穿黑色 T 恤；多数为正面白底 3D Memoji 头像。Skill 内置多个样例用于展示风格范围，并以 `assets/ucars-avatar-style-reference.png` 作为默认服装、挂绳和工牌锚点。用户本轮提供的模板或明确指示优先。
- 为避免员工头像像同一张脸，严格按每张真人照片保留不同脸宽、眉眼、鼻型和真实发型；不通过随机换发型、改五官或美化来制造差异。
- 挂绳重复字、工牌上的细小文字可能失真。优先保留简洁标志与黄色色块，不要生成姓名等小字；如要求精确品牌标识，应提醒用户核验或后期替换为正式 Logo 文件。
